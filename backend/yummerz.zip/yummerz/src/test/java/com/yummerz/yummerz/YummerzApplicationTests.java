package com.yummerz.yummerz;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YummerzApplicationTests {

	@Test
	void contextLoads() {
	}

}
