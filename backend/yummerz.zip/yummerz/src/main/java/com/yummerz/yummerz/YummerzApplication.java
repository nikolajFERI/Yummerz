package com.yummerz.yummerz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class YummerzApplication {

	public static void main(String[] args) {
		SpringApplication.run(YummerzApplication.class, args);
	}

}
